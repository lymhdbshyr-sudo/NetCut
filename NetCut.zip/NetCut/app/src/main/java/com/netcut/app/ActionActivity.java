package com.netcut.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

/** نقطة دخول شفافة للاختصارات: تنفذ المهمة دون إظهار واجهة التطبيق. */
public class ActionActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        String a = getIntent().getAction();
        NetAccessService s = NetAccessService.instance;
        if (s == null) {
            Toast.makeText(this, "فعّل «قاطع الإنترنت» من إمكانية الوصول أولاً", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            finish();
            return;
        }
        int mode;
        if ("com.netcut.app.OPEN_LAST".equals(a)) mode = NetAccessService.MODE_OPEN;
        else if ("com.netcut.app.BLOCK".equals(a)) mode = NetAccessService.MODE_BLOCK;
        else if ("com.netcut.app.RESTORE".equals(a)) mode = NetAccessService.MODE_RESTORE;
        else mode = NetAccessService.isBlocked(this) ? NetAccessService.MODE_RESTORE : NetAccessService.MODE_BLOCK;
        s.begin(mode);
        startActivity(NetAccessService.firstIntent(this));
        finish();
        overridePendingTransition(0, 0);
    }
}
