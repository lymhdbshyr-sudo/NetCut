package com.netcut.app;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import android.service.quicksettings.TileService;

/** VPN محلي يبتلع كل الحزم: لا تُقرأ ولا تُرسل، فينقطع الإنترنت عن كل التطبيقات. */
public class BlockVpnService extends VpnService {
    public static final String ACTION_START = "com.netcut.app.START";
    public static final String ACTION_STOP = "com.netcut.app.STOP";
    static final String PREFS = "netcut";
    static final String KEY_BLOCKED = "blocked";

    private ParcelFileDescriptor tun;

    public static boolean isBlocked(Context c) {
        return c.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_BLOCKED, false);
    }

    private void setBlocked(boolean b) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_BLOCKED, b).apply();
        try {
            TileService.requestListeningState(this, new ComponentName(this, InternetTileService.class));
        } catch (Exception ignored) {}
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(a)) {
            closeTun();
            setBlocked(false);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (tun == null) {
            try {
                Builder b = new Builder()
                        .setSession("Internet Off")
                        .addAddress("10.255.255.1", 32)
                        .addAddress("fd00::1", 128)
                        .addRoute("0.0.0.0", 0)
                        .addRoute("::", 0)
                        .setMtu(1500);
                tun = b.establish();
            } catch (Exception e) {
                tun = null;
            }
        }
        setBlocked(tun != null);
        if (tun == null) stopSelf();
        return START_STICKY;
    }

    private void closeTun() {
        try { if (tun != null) tun.close(); } catch (Exception ignored) {}
        tun = null;
    }

    @Override
    public void onRevoke() {
        closeTun();
        setBlocked(false);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        closeTun();
        setBlocked(false);
        super.onDestroy();
    }
}
