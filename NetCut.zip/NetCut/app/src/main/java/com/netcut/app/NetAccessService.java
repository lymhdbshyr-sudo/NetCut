package com.netcut.app;

import android.accessibilityservice.AccessibilityService;
import android.animation.ObjectAnimator;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.service.quicksettings.TileService;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * يدخل إلى «الاتصال بالشبكة» ويلغي (أو يعيد) تحديد صف «الكل».
 * يعمل بالأحداث (بدون انتظار ثابت) ويتعلم سرعة الهاتف تلقائياً.
 */
public class NetAccessService extends AccessibilityService {
    public static final int MODE_NONE = 0, MODE_BLOCK = 1, MODE_RESTORE = 2, MODE_OPEN = 3;
    public static NetAccessService instance;

    static final String PREFS = "netcut";
    static final String KEY_BLOCKED = "blocked";
    static final String KEY_DUMP = "dump";
    static final String KEY_WAIT = "wait_ms";
    static final long WAIT_MIN = 90, WAIT_MAX = 1800, WAIT_START = 300;

    private final Handler h = new Handler(Looper.getMainLooper());
    private int mode = MODE_NONE;
    private long startTime;
    private String lastDump = "";
    private boolean scheduled;

    // التعلم التلقائي لسرعة الهاتف
    private long waitMs = WAIT_START;
    private String sigAtClick;
    private long clickTime;
    private long unknownSince;
    private boolean relaunched;

    private View overlay;
    private ObjectAnimator pulse;

    public static boolean isBlocked(Context c) {
        return c.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_BLOCKED, false);
    }

    /** أول شاشة نفتحها: صفحة استخدام البيانات مباشرة، وإلا الإعدادات الرئيسية. */
    public static Intent firstIntent(Context c) {
        Intent i = new Intent(Settings.ACTION_DATA_USAGE_SETTINGS);
        if (i.resolveActivity(c.getPackageManager()) == null) i = new Intent(Settings.ACTION_SETTINGS);
        return i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
    }

    @Override protected void onServiceConnected() { instance = this; }
    @Override public boolean onUnbind(Intent i) { instance = null; hideOverlay(); return super.onUnbind(i); }
    @Override public void onInterrupt() { }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (mode != MODE_NONE) kick();
    }

    public void begin(int m) {
        mode = m;
        startTime = SystemClock.uptimeMillis();
        sigAtClick = null;
        unknownSince = 0;
        relaunched = false;
        waitMs = getSharedPreferences(PREFS, MODE_PRIVATE).getLong(KEY_WAIT, WAIT_START);
        h.removeCallbacksAndMessages(null);
        scheduled = false;
        if (m != MODE_OPEN) showOverlay(m == MODE_BLOCK ? "جارٍ فصل الإنترنت…" : "جارٍ استعادة الإنترنت…");
        kick();
        h.postDelayed(this::watchdog, 150);
    }

    private void kick() {
        if (scheduled) return;
        scheduled = true;
        h.postDelayed(this::stepRun, 12);
    }

    private void watchdog() {
        if (mode == MODE_NONE) return;
        kick();
        h.postDelayed(this::watchdog, 120);
    }

    private void stepRun() {
        scheduled = false;
        if (mode == MODE_NONE) return;
        if (SystemClock.uptimeMillis() - startTime > 30000) { finish(false); return; }
        try { step(); } catch (Exception ignored) { }
    }

    private void step() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        lastDump = dump(root);
        long now = SystemClock.uptimeMillis();

        List<AccessibilityNodeInfo> boxes = new ArrayList<>();
        collectCheckable(root, boxes);
        List<AccessibilityNodeInfo> row = null;
        String sig;
        if (findExact(root, "الكل") != null && boxes.size() >= 2) {
            row = firstRow(boxes);
            StringBuilder sb = new StringBuilder("D:");
            for (AccessibilityNodeInfo n : row) sb.append(n.isChecked() ? '1' : '0');
            sig = sb.toString();
        } else if (hasText(root, "موفر البيانات") && hasText(root, "الاتصال بالشبكة")) {
            sig = "C";
        } else if (hasText(root, "استخدام البيانات")
                && (hasText(root, "إدارة بطاقتي") || hasText(root, "وضع الطائرة"))) {
            sig = "B";
        } else if (hasText(root, "شبكة الجوال")) {
            sig = "A";
        } else {
            sig = null;
        }

        if (sig == null) {
            // صفحة غير معروفة: لو طالت نعيد الفتح من الإعدادات الرئيسية مرة واحدة
            if (unknownSince == 0) unknownSince = now;
            if (!relaunched && now - unknownSince > Math.max(1400, waitMs * 3)) {
                relaunched = true;
                unknownSince = 0;
                try {
                    startActivity(new Intent(Settings.ACTION_SETTINGS)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                } catch (Exception ignored) { }
            }
            return;
        }
        unknownSince = 0;

        // دائرة التحميل: ننتظر زوالها
        if (hasText(root, "جار التحميل") || hasText(root, "جارٍ التحميل")) return;

        // ضبط الانتظار تلقائياً حسب سرعة الهاتف
        if (sigAtClick != null) {
            long el = now - clickTime;
            if (sig.equals(sigAtClick)) {
                if (el < waitMs) return;                       // ما زلنا ننتظر
                waitMs = Math.min(WAIT_MAX, (long) (waitMs * 1.7) + 30); // الهاتف أبطأ: نبطّئ
            } else {
                long target = (long) (el * 2.5) + 40;           // نجح: نتعلم سرعته
                waitMs = clamp((long) (0.6 * waitMs + 0.4 * target), WAIT_MIN, WAIT_MAX);
            }
            sigAtClick = null;
        }

        if (row != null) {
            if (mode == MODE_OPEN) { finish(true); return; }
            boolean desired = (mode == MODE_RESTORE);
            for (AccessibilityNodeInfo n : row) {
                if (n.isChecked() != desired) {
                    if (clickNode(n)) { sigAtClick = sig; clickTime = now; }
                    return;
                }
            }
            finish(true);
            return;
        }

        boolean ok = false;
        if (sig.equals("C")) ok = clickText(root, "الاتصال بالشبكة");
        else if (sig.equals("B")) ok = clickText(root, "استخدام البيانات");
        else if (sig.equals("A")) ok = clickText(root, "شبكة الجوال");
        if (ok) { sigAtClick = sig; clickTime = now; }
    }

    private static long clamp(long v, long lo, long hi) { return Math.max(lo, Math.min(hi, v)); }

    private void finish(boolean ok) {
        int m = mode;
        mode = MODE_NONE;
        h.removeCallbacksAndMessages(null);
        scheduled = false;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_DUMP, lastDump)
                .putLong(KEY_WAIT, waitMs).apply();
        if (ok) {
            if (m == MODE_BLOCK || m == MODE_RESTORE) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_BLOCKED, m == MODE_BLOCK).apply();
                performGlobalAction(GLOBAL_ACTION_HOME);
                h.postDelayed(this::hideOverlay, 260);
                ShortcutHelper.update(this, m == MODE_BLOCK);
            }
        } else {
            hideOverlay();
            Toast.makeText(this, "تعذر إكمال الخطوات. افتح التطبيق واضغط «نسخ تقرير الشاشة»", Toast.LENGTH_LONG).show();
        }
        try {
            TileService.requestListeningState(this, new ComponentName(this, InternetTileService.class));
        } catch (Exception ignored) { }
    }

    // ---------- أدوات الشجرة ----------

    private List<AccessibilityNodeInfo> firstRow(List<AccessibilityNodeInfo> boxes) {
        int minTop = Integer.MAX_VALUE;
        Rect r = new Rect();
        for (AccessibilityNodeInfo n : boxes) { n.getBoundsInScreen(r); minTop = Math.min(minTop, r.top); }
        List<AccessibilityNodeInfo> row = new ArrayList<>();
        for (AccessibilityNodeInfo n : boxes) { n.getBoundsInScreen(r); if (r.top <= minTop + 40) row.add(n); }
        Collections.sort(row, (a, b) -> {
            Rect x = new Rect(), y = new Rect();
            a.getBoundsInScreen(x); b.getBoundsInScreen(y);
            return x.left - y.left;
        });
        return row;
    }

    private void collectCheckable(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out) {
        if (n == null) return;
        if (n.isCheckable() && n.isVisibleToUser()) out.add(n);
        for (int i = 0; i < n.getChildCount(); i++) collectCheckable(n.getChild(i), out);
    }

    private AccessibilityNodeInfo findExact(AccessibilityNodeInfo root, String t) {
        List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(t);
        if (l == null) return null;
        for (AccessibilityNodeInfo n : l) {
            CharSequence s = n.getText();
            if (s != null && s.toString().trim().equals(t)) return n;
        }
        return null;
    }

    private boolean hasText(AccessibilityNodeInfo root, String t) {
        List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(t);
        return l != null && !l.isEmpty();
    }

    private boolean clickText(AccessibilityNodeInfo root, String t) {
        List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(t);
        if (l == null) return false;
        for (AccessibilityNodeInfo n : l) if (clickNode(n)) return true;
        return false;
    }

    private boolean clickNode(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo c = n;
        while (c != null && !c.isClickable()) c = c.getParent();
        if (c == null) return false;
        return c.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private String dump(AccessibilityNodeInfo root) {
        StringBuilder sb = new StringBuilder();
        dumpRec(root, 0, sb, new int[]{0});
        return sb.toString();
    }

    private void dumpRec(AccessibilityNodeInfo n, int d, StringBuilder sb, int[] cnt) {
        if (n == null || cnt[0] > 250) return;
        cnt[0]++;
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        String cls = n.getClassName() == null ? "" : n.getClassName().toString();
        cls = cls.substring(cls.lastIndexOf('.') + 1);
        for (int i = 0; i < d; i++) sb.append(' ');
        sb.append(cls)
          .append(" t=").append(n.getText())
          .append(" d=").append(n.getContentDescription())
          .append(n.isClickable() ? " [click]" : "")
          .append(n.isCheckable() ? (n.isChecked() ? " [checked]" : " [unchecked]") : "")
          .append(" ").append(r.toShortString()).append("\n");
        for (int i = 0; i < n.getChildCount(); i++) dumpRec(n.getChild(i), d + 1, sb, cnt);
    }

    // ---------- شاشة الانتظار ----------

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private Typeface tasbihFont() {
        try { return Typeface.createFromAsset(getAssets(), "fonts/tasbih.ttf"); }
        catch (Exception e) { return Typeface.create("serif", Typeface.BOLD); }
    }

    private TextView tv(String text, int sp, int color, Typeface tf, boolean glow) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (tf != null) t.setTypeface(tf);
        if (glow) t.setShadowLayer(dp(12), 0, 0, (color & 0x00FFFFFF) | 0xB0000000);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(topDp);
        p.gravity = Gravity.CENTER_HORIZONTAL;
        return p;
    }

    private void showOverlay(String msg) {
        if (overlay != null) return;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            Typeface tf = tasbihFont();
            final int gold = 0xFFE9C46A, cream = 0xFFFFF1CC;

            FrameLayout f = new FrameLayout(this);
            f.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            f.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0xFF03171E, 0xFF0A3238, 0xFF0F1C33}));

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER);
            col.setPadding(dp(24), dp(24), dp(24), dp(24));

            TextView orn = tv("۞", 46, gold, tf, true);
            View line1 = new View(this);
            line1.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{0x00E9C46A, 0xFFE9C46A, 0x00E9C46A}));
            TextView t1 = tv("سبحان الله وبحمده", 40, gold, tf, true);
            TextView t2 = tv("سبحان الله العظيم", 36, cream, tf, true);
            View line2 = new View(this);
            line2.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{0x00E9C46A, 0xFFE9C46A, 0x00E9C46A}));
            TextView st = tv(msg, 15, 0xFF9FC4BF, null, false);
            TextView cn = tv("المس الشاشة للإلغاء", 12, 0xFF5E8480, null, false);

            col.addView(orn, lp(-2, -2, 0));
            col.addView(line1, lp(dp(190), dp(2), 8));
            col.addView(t1, lp(-2, -2, 22));
            col.addView(t2, lp(-2, -2, 6));
            col.addView(line2, lp(dp(190), dp(2), 22));
            col.addView(st, lp(-2, -2, 22));
            col.addView(cn, lp(-2, -2, 6));
            f.addView(col, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));

            // حركة ظهور هادئة
            for (View v : new View[]{t1, t2, st, cn}) { v.setAlpha(0f); v.setTranslationY(dp(16)); }
            t1.animate().alpha(1f).translationY(0f).setStartDelay(60).setDuration(550).start();
            t2.animate().alpha(1f).translationY(0f).setStartDelay(260).setDuration(550).start();
            st.animate().alpha(1f).translationY(0f).setStartDelay(520).setDuration(450).start();
            cn.animate().alpha(1f).translationY(0f).setStartDelay(700).setDuration(450).start();
            pulse = ObjectAnimator.ofFloat(orn, "alpha", 0.35f, 1f);
            pulse.setDuration(1300);
            pulse.setRepeatCount(ObjectAnimator.INFINITE);
            pulse.setRepeatMode(ObjectAnimator.REVERSE);
            pulse.setInterpolator(new AccelerateDecelerateInterpolator());
            pulse.start();

            f.setOnClickListener(v -> { mode = MODE_NONE; h.removeCallbacksAndMessages(null); hideOverlay(); });
            WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            wm.addView(f, p);
            overlay = f;
        } catch (Exception e) { overlay = null; }
    }

    private void hideOverlay() {
        if (pulse != null) { pulse.cancel(); pulse = null; }
        if (overlay == null) return;
        try { ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(overlay); }
        catch (Exception ignored) { }
        overlay = null;
    }
}
