package com.netcut.app;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.service.quicksettings.TileService;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * يدخل: الإعدادات ← شبكة الجوال ← استخدام البيانات ← الاتصال بالشبكة
 * ثم يلغي (أو يعيد) تحديد صف «الكل» تماماً كما تفعل بيدك.
 */
public class NetAccessService extends AccessibilityService {
    public static final int MODE_NONE = 0, MODE_BLOCK = 1, MODE_RESTORE = 2, MODE_OPEN = 3;
    public static NetAccessService instance;

    static final String PREFS = "netcut";
    static final String KEY_BLOCKED = "blocked";
    static final String KEY_DUMP = "dump";

    private final Handler h = new Handler(Looper.getMainLooper());
    private int mode = MODE_NONE;
    private long startTime, lastClick;
    private int toggles;
    private String lastDump = "";
    private View overlay;
    private long gap = 600;

    public static boolean isBlocked(Context c) {
        return c.getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_BLOCKED, false);
    }

    @Override protected void onServiceConnected() { instance = this; }
    @Override public boolean onUnbind(Intent i) { instance = null; return super.onUnbind(i); }
    @Override public void onAccessibilityEvent(AccessibilityEvent e) { }
    @Override public void onInterrupt() { }

    /** يبدأ المهمة. بعدها يجب فتح الإعدادات (يفعلها المستدعي). */
    public void begin(int m) {
        mode = m;
        startTime = SystemClock.uptimeMillis();
        lastClick = 0;
        toggles = 0;
        h.removeCallbacksAndMessages(null);
        if (m != MODE_OPEN) showOverlay(m == MODE_BLOCK ? "جارٍ فصل الإنترنت…" : "جارٍ استعادة الإنترنت…");
        h.postDelayed(this::tick, 900);
    }

    private void tick() {
        if (mode == MODE_NONE) return;
        if (SystemClock.uptimeMillis() - startTime > 35000) { finish(false); return; }
        boolean again;
        try { again = step(); } catch (Exception e) { again = true; }
        if (again) h.postDelayed(this::tick, 350);
    }

    private boolean step() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return true;
        lastDump = dump(root);
        if (hasText(root, "جار التحميل") || hasText(root, "جارٍ التحميل")) return true;

        // الصفحة الأخيرة: «الاتصال بالشبكة» وفيها صف «الكل»
        List<AccessibilityNodeInfo> boxes = new ArrayList<>();
        collectCheckable(root, boxes);
        if (findExact(root, "الكل") != null && boxes.size() >= 2) {
            if (mode == MODE_OPEN) { finish(true); return false; }
            List<AccessibilityNodeInfo> row = firstRow(boxes);
            boolean desired = (mode == MODE_RESTORE);
            for (AccessibilityNodeInfo n : row) {
                if (n.isChecked() != desired) {
                    if (toggles > 12) { finish(false); return false; }
                    if (!canClick()) return true;
                    gap = 900;
                    clickNode(n);
                    toggles++;
                    return true;
                }
            }
            finish(true);
            return false;
        }

        gap = 600;
        if (!canClick()) return true;

        // صفحة «استخدام البيانات»
        if (hasText(root, "موفر البيانات") && clickText(root, "الاتصال بالشبكة")) return true;
        // صفحة «شبكة الجوال»
        if (hasText(root, "استخدام البيانات")
                && (hasText(root, "إدارة بطاقتي") || hasText(root, "وضع الطائرة"))
                && clickText(root, "استخدام البيانات")) return true;
        // صفحة الإعدادات الرئيسية
        if (hasText(root, "شبكة الجوال") && clickText(root, "شبكة الجوال")) return true;
        return true;
    }

    private void finish(boolean ok) {
        int m = mode;
        mode = MODE_NONE;
        h.removeCallbacksAndMessages(null);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_DUMP, lastDump).apply();
        if (ok) {
            if (m == MODE_BLOCK || m == MODE_RESTORE) {
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_BLOCKED, m == MODE_BLOCK).apply();
                Toast.makeText(this, m == MODE_BLOCK ? "تم فصل الإنترنت" : "تمت استعادة الإنترنت", Toast.LENGTH_SHORT).show();
                h.postDelayed(() -> performGlobalAction(GLOBAL_ACTION_HOME), 500);
                h.postDelayed(this::hideOverlay, 1100);
            } else hideOverlay();
        } else {
            hideOverlay();
            Toast.makeText(this, "تعذر إكمال الخطوات. افتح التطبيق واضغط «نسخ تقرير الشاشة»", Toast.LENGTH_LONG).show();
        }
        try {
            TileService.requestListeningState(this, new ComponentName(this, InternetTileService.class));
        } catch (Exception ignored) { }
    }


    private boolean canClick() { return SystemClock.uptimeMillis() - lastClick > gap; }

    private List<AccessibilityNodeInfo> firstRow(List<AccessibilityNodeInfo> boxes) {
        int minTop = Integer.MAX_VALUE;
        Rect r = new Rect();
        for (AccessibilityNodeInfo n : boxes) { n.getBoundsInScreen(r); minTop = Math.min(minTop, r.top); }
        List<AccessibilityNodeInfo> row = new ArrayList<>();
        for (AccessibilityNodeInfo n : boxes) { n.getBoundsInScreen(r); if (r.top <= minTop + 40) row.add(n); }
        Collections.sort(row, (a, b) -> {
            Rect x = new Rect(), y = new Rect();
            a.getBoundsInScreen(x); b.getBoundsInScreen(y);
            return x.left - y.left;
        });
        return row;
    }

    private void collectCheckable(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out) {
        if (n == null) return;
        if (n.isCheckable() && n.isVisibleToUser()) out.add(n);
        for (int i = 0; i < n.getChildCount(); i++) collectCheckable(n.getChild(i), out);
    }

    private AccessibilityNodeInfo findExact(AccessibilityNodeInfo root, String t) {
        List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(t);
        if (l == null) return null;
        for (AccessibilityNodeInfo n : l) {
            CharSequence s = n.getText();
            if (s != null && s.toString().trim().equals(t)) return n;
        }
        return null;
    }

    private boolean hasText(AccessibilityNodeInfo root, String t) {
        List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(t);
        return l != null && !l.isEmpty();
    }

    private boolean clickText(AccessibilityNodeInfo root, String t) {
        List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(t);
        if (l == null) return false;
        for (AccessibilityNodeInfo n : l) {
            if (clickNode(n)) { lastClick = SystemClock.uptimeMillis(); return true; }
        }
        return false;
    }

    private boolean clickNode(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo c = n;
        while (c != null && !c.isClickable()) c = c.getParent();
        if (c == null) return false;
        lastClick = SystemClock.uptimeMillis();
        return c.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    /** شاشة تغطي حركة الإعدادات أثناء التنفيذ. اللمس عليها يلغي العملية. */
    private void showOverlay(String msg) {
        if (overlay != null) return;
        try {
            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            FrameLayout f = new FrameLayout(this);
            f.setBackgroundColor(0xFA121212);
            f.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            TextView t = new TextView(this);
            t.setText(msg + "\n\n(المس الشاشة للإلغاء)");
            t.setTextColor(0xFFFFFFFF);
            t.setTextSize(22);
            t.setGravity(Gravity.CENTER);
            f.addView(t, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            f.setOnClickListener(v -> { mode = MODE_NONE; h.removeCallbacksAndMessages(null); hideOverlay(); });
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            wm.addView(f, lp);
            overlay = f;
        } catch (Exception e) { overlay = null; }
    }

    private void hideOverlay() {
        if (overlay == null) return;
        try {
            ((WindowManager) getSystemService(WINDOW_SERVICE)).removeView(overlay);
        } catch (Exception ignored) { }
        overlay = null;
    }

    private String dump(AccessibilityNodeInfo root) {
        StringBuilder sb = new StringBuilder();
        dumpRec(root, 0, sb, new int[]{0});
        return sb.toString();
    }

    private void dumpRec(AccessibilityNodeInfo n, int d, StringBuilder sb, int[] cnt) {
        if (n == null || cnt[0] > 250) return;
        cnt[0]++;
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        String cls = n.getClassName() == null ? "" : n.getClassName().toString();
        cls = cls.substring(cls.lastIndexOf('.') + 1);
        for (int i = 0; i < d; i++) sb.append(' ');
        sb.append(cls)
          .append(" t=").append(n.getText())
          .append(" d=").append(n.getContentDescription())
          .append(n.isClickable() ? " [click]" : "")
          .append(n.isCheckable() ? (n.isChecked() ? " [checked]" : " [unchecked]") : "")
          .append(" ").append(r.toShortString()).append("\n");
        for (int i = 0; i < n.getChildCount(); i++) dumpRec(n.getChild(i), d + 1, sb, cnt);
    }
}
