package com.netcut.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Icon;

import java.util.Collections;

/** اختصار واحد تفاعلي: يتغير لونه وشكله واسمه حسب الحالة. */
public class ShortcutHelper {
    static final String ID = "pin_toggle";

    static Bitmap icon(boolean blocked) {
        int bgc = blocked ? 0xFFC62828 : 0xFF2E7D32;
        Bitmap bm = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(bgc);
        c.drawCircle(128, 128, 128, p);

        // إشارة واي فاي
        p.setColor(0xFFFFFFFF);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(15);
        float cx = 128, cy = 178;
        for (float r : new float[]{36, 66, 96}) {
            c.drawArc(new RectF(cx - r, cy - r, cx + r, cy + r), 228, 84, false, p);
        }
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(cx, cy - 2, 10, p);

        if (blocked) {
            Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
            s.setStyle(Paint.Style.STROKE);
            s.setStrokeCap(Paint.Cap.ROUND);
            s.setColor(bgc);
            s.setStrokeWidth(36);
            c.drawLine(62, 62, 194, 194, s);
            s.setColor(0xFFFFFFFF);
            s.setStrokeWidth(16);
            c.drawLine(62, 62, 194, 194, s);
        }
        return bm;
    }

    static ShortcutInfo info(Context c, boolean blocked) {
        String label = blocked ? "استعادة الإنترنت" : "فصل الإنترنت";
        Intent i = new Intent(c, ActionActivity.class).setAction("com.netcut.app.TOGGLE");
        return new ShortcutInfo.Builder(c, ID)
                .setShortLabel(label)
                .setLongLabel(label)
                .setIcon(Icon.createWithBitmap(icon(blocked)))
                .setIntent(i)
                .build();
    }

    /** يحدّث الاختصار المثبّت (وقائمة الضغط المطوّل) ليطابق الحالة الحالية. */
    static void update(Context c, boolean blocked) {
        try {
            ShortcutManager sm = c.getSystemService(ShortcutManager.class);
            if (sm == null) return;
            sm.setDynamicShortcuts(Collections.singletonList(info(c, blocked)));
        } catch (Exception ignored) { }
    }
}
