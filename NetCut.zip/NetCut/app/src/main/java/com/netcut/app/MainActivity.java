package com.netcut.app;

import android.app.Activity;
import android.app.StatusBarManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ShortcutManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private Button toggle, enable;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(48, 96, 48, 48);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(Color.parseColor("#121212"));

        status = new TextView(this);
        status.setTextSize(22);
        status.setTextColor(Color.WHITE);
        status.setGravity(Gravity.CENTER);
        root.addView(status, lp(36));

        toggle = new Button(this);
        toggle.setTextSize(22);
        toggle.setTextColor(Color.WHITE);
        toggle.setOnClickListener(v -> run(NetAccessService.isBlocked(this)
                ? NetAccessService.MODE_RESTORE : NetAccessService.MODE_BLOCK));
        LinearLayout.LayoutParams big = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 340);
        big.bottomMargin = 36;
        root.addView(toggle, big);

        Button last = new Button(this);
        last.setText("الذهاب لآخر خطوة (أوقفه بنفسك)");
        last.setOnClickListener(v -> run(NetAccessService.MODE_OPEN));
        root.addView(last, lp(20));

        enable = new Button(this);
        enable.setText("① تفعيل خدمة إمكانية الوصول");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(enable, lp(20));

        Button addTile = new Button(this);
        addTile.setText("② إضافة زر لشريط الاختصارات");
        addTile.setOnClickListener(v -> requestTile());
        root.addView(addTile, lp(20));

        Button pin = new Button(this);
        pin.setText("③ إضافة الاختصار التفاعلي للشاشة الرئيسية");
        pin.setOnClickListener(v -> pinShortcut());
        root.addView(pin, lp(20));

        Button copy = new Button(this);
        copy.setText("نسخ تقرير الشاشة (للمساعدة عند الفشل)");
        copy.setOnClickListener(v -> copyDump());
        root.addView(copy, lp(20));

        TextView hint = new TextView(this);
        hint.setTextColor(Color.parseColor("#AAAAAA"));
        hint.setTextSize(14);
        hint.setText("يعمل بالضغط على خيارات «الكل» في: الإعدادات ← استخدام البيانات ← الاتصال بالشبكة، تماماً كما تفعل بيدك، ويتعلم سرعة هاتفك تلقائياً فيصير أسرع مع كل مرة.\n\n"
                + "لو الخيار رمادي عند التفعيل: إعدادات الهاتف ← التطبيقات ← قاطع الإنترنت ← النقاط الثلاث ← «السماح بالإعدادات المقيّدة»، ثم أعد المحاولة.\n\n"
                + "الاختصار التفاعلي يتغير لونه وشكله واسمه حسب حالة الإنترنت. لو لم يظهر بعد الموافقة: إعدادات الهاتف ← التطبيقات ← قاطع الإنترنت ← الأذونات ← فعّل «إنشاء اختصار على سطح المكتب».");
        root.addView(hint);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    private LinearLayout.LayoutParams lp(int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = bottom;
        return p;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (toggle == null) return;
        boolean on = NetAccessService.instance != null;
        boolean blocked = NetAccessService.isBlocked(this);
        status.setText(!on ? "⚠️ فعّل خدمة إمكانية الوصول أولاً"
                : blocked ? "🚫 الإنترنت مفصول" : "✅ الإنترنت يعمل");
        toggle.setText(blocked ? "استعادة الإنترنت" : "فصل الإنترنت");
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(48);
        g.setColor(Color.parseColor(blocked ? "#2E7D32" : "#C62828"));
        toggle.setBackground(g);
        enable.setVisibility(on ? View.GONE : View.VISIBLE);
        ShortcutHelper.update(this, blocked);
    }

    private void run(int mode) {
        NetAccessService s = NetAccessService.instance;
        if (s == null) {
            Toast.makeText(this, "فعّل «قاطع الإنترنت» من إمكانية الوصول ثم ارجع", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            return;
        }
        s.begin(mode);
        startActivity(NetAccessService.firstIntent(this));
    }

    private void copyDump() {
        String d = getSharedPreferences(NetAccessService.PREFS, MODE_PRIVATE).getString(NetAccessService.KEY_DUMP, "");
        if (d.isEmpty()) { Toast.makeText(this, "لا يوجد تقرير بعد، جرّب الفصل مرة", Toast.LENGTH_LONG).show(); return; }
        ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("report", d));
        Toast.makeText(this, "تم النسخ، الصقه في المحادثة", Toast.LENGTH_LONG).show();
    }

    private void pinShortcut() {
        ShortcutManager sm = getSystemService(ShortcutManager.class);
        if (sm == null || !sm.isRequestPinShortcutSupported()) {
            Toast.makeText(this, "شاشتك الرئيسية لا تدعم إضافة اختصار من التطبيق", Toast.LENGTH_LONG).show();
            return;
        }
        sm.requestPinShortcut(ShortcutHelper.info(this, NetAccessService.isBlocked(this)), null);
        Toast.makeText(this, "وافق على إضافة الاختصار في النافذة التي تظهر", Toast.LENGTH_LONG).show();
    }

    private void requestTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            StatusBarManager sbm = getSystemService(StatusBarManager.class);
            sbm.requestAddTileService(
                    new ComponentName(this, InternetTileService.class),
                    "فصل الإنترنت",
                    Icon.createWithResource(this, R.drawable.ic_tile),
                    getMainExecutor(),
                    result -> { });
        } else {
            Toast.makeText(this, "اسحب الشريط ← تعديل ← أضف «فصل الإنترنت»", Toast.LENGTH_LONG).show();
        }
    }
}
