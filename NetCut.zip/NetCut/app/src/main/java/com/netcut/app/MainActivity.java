package com.netcut.app;

import android.app.Activity;
import android.app.StatusBarManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_VPN = 1;
    private Button toggle;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        // اختصار "لوحة الإنترنت": يفتح آخر خطوة (الإيقاف اليدوي) مباشرة
        if ("com.netcut.app.PANEL".equals(getIntent().getAction())) {
            openPanel();
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(48, 96, 48, 48);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(Color.parseColor("#121212"));

        status = new TextView(this);
        status.setTextSize(24);
        status.setTextColor(Color.WHITE);
        status.setGravity(Gravity.CENTER);
        root.addView(status, lp(48));

        toggle = new Button(this);
        toggle.setTextSize(22);
        toggle.setTextColor(Color.WHITE);
        toggle.setOnClickListener(v -> onToggle());
        LinearLayout.LayoutParams big = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 360);
        big.bottomMargin = 48;
        root.addView(toggle, big);

        Button panel = new Button(this);
        panel.setText("فتح لوحة الإنترنت (إيقاف يدوي)");
        panel.setOnClickListener(v -> openPanel());
        root.addView(panel, lp(24));

        Button addTile = new Button(this);
        addTile.setText("إضافة زر فصل الإنترنت لشريط الاختصارات");
        addTile.setOnClickListener(v -> requestTile());
        root.addView(addTile, lp(24));

        TextView hint = new TextView(this);
        hint.setTextColor(Color.parseColor("#AAAAAA"));
        hint.setTextSize(14);
        hint.setText("لو ما ظهر الزر في الشريط: اسحب الشريط ← أيقونة التعديل ← اسحب «فصل الإنترنت» إلى الأعلى.\n\nالفصل يتم عبر VPN محلي (يظهر مفتاح في الشريط العلوي) ولا يخرج أي بيانات من الجهاز.\n\nاختصار الإيقاف اليدوي: اضغط مطولاً على أيقونة التطبيق ← «لوحة الإنترنت».");
        root.addView(hint);

        setContentView(root);
        refresh();

        if (getIntent().getBooleanExtra("autoblock", false)) startBlock();
    }

    private LinearLayout.LayoutParams lp(int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = bottom;
        return p;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (toggle != null) refresh();
    }

    private void refresh() {
        boolean blocked = BlockVpnService.isBlocked(this);
        status.setText(blocked ? "🚫 الإنترنت مفصول عن كل التطبيقات" : "✅ الإنترنت يعمل");
        toggle.setText(blocked ? "استعادة الإنترنت" : "فصل الإنترنت");
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(48);
        g.setColor(Color.parseColor(blocked ? "#2E7D32" : "#C62828"));
        toggle.setBackground(g);
    }

    private void onToggle() {
        if (BlockVpnService.isBlocked(this)) {
            startService(new Intent(this, BlockVpnService.class).setAction(BlockVpnService.ACTION_STOP));
            toggle.postDelayed(this::refresh, 500);
        } else {
            startBlock();
        }
    }

    private void startBlock() {
        Intent i = VpnService.prepare(this);
        if (i != null) {
            startActivityForResult(i, REQ_VPN);
        } else {
            startService(new Intent(this, BlockVpnService.class).setAction(BlockVpnService.ACTION_START));
            if (toggle != null) toggle.postDelayed(this::refresh, 500);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_VPN) {
            if (res == RESULT_OK) startBlock();
            else Toast.makeText(this, "لازم توافق على طلب VPN لكي يعمل الفصل", Toast.LENGTH_LONG).show();
        }
    }

    private void openPanel() {
        try {
            startActivity(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY));
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); }
            catch (Exception ignored) {}
        }
    }

    private void requestTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            StatusBarManager sbm = getSystemService(StatusBarManager.class);
            sbm.requestAddTileService(
                    new ComponentName(this, InternetTileService.class),
                    "فصل الإنترنت",
                    Icon.createWithResource(this, R.drawable.ic_tile),
                    getMainExecutor(),
                    result -> { });
        } else {
            Toast.makeText(this, "اسحب الشريط ← تعديل ← أضف «فصل الإنترنت»", Toast.LENGTH_LONG).show();
        }
    }
}
