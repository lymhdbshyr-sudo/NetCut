package com.netcut.app;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.widget.Toast;

public class InternetTileService extends TileService {

    @Override
    public void onStartListening() { setTileState(NetAccessService.isBlocked(this)); }

    @Override
    public void onClick() {
        NetAccessService svc = NetAccessService.instance;
        if (svc == null) {
            Toast.makeText(this, "فعّل خدمة «قاطع الإنترنت» من إمكانية الوصول أولاً", Toast.LENGTH_LONG).show();
            Intent i = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            launch(i);
            return;
        }
        boolean blocked = NetAccessService.isBlocked(this);
        svc.begin(blocked ? NetAccessService.MODE_RESTORE : NetAccessService.MODE_BLOCK);
        launch(NetAccessService.firstIntent(this));
    }

    private void launch(Intent i) {
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        } else {
            startActivityAndCollapse(i);
        }
    }

    private void setTileState(boolean blocked) {
        Tile t = getQsTile();
        if (t == null) return;
        t.setState(blocked ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.setLabel(blocked ? "الإنترنت مفصول" : "فصل الإنترنت");
        t.updateTile();
    }
}
