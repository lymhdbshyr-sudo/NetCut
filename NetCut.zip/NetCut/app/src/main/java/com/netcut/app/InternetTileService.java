package com.netcut.app;

import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class InternetTileService extends TileService {

    @Override
    public void onStartListening() { refresh(); }

    @Override
    public void onClick() {
        boolean wasBlocked = BlockVpnService.isBlocked(this);
        if (wasBlocked) {
            startService(new Intent(this, BlockVpnService.class).setAction(BlockVpnService.ACTION_STOP));
        } else if (VpnService.prepare(this) != null) {
            // أول مرة: لازم موافقة النظام، نفتح التطبيق لعرضها
            Intent i = new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra("autoblock", true);
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(PendingIntent.getActivity(this, 0, i,
                        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
            } else {
                startActivityAndCollapse(i);
            }
            return;
        } else {
            startService(new Intent(this, BlockVpnService.class).setAction(BlockVpnService.ACTION_START));
        }
        setTileState(!wasBlocked);
    }

    private void refresh() { setTileState(BlockVpnService.isBlocked(this)); }

    private void setTileState(boolean blocked) {
        Tile t = getQsTile();
        if (t == null) return;
        t.setState(blocked ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.setLabel(blocked ? "الإنترنت مفصول" : "فصل الإنترنت");
        t.updateTile();
    }
}
